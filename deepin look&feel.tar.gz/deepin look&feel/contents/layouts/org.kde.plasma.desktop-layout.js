var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.image"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "/home/eduardo/Descargas/Telegram Desktop/photo_2018-06-19_10-22-29.jpg"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        },
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.video"
                },
                "/ConfigDialog": {
                    "DialogHeight": "540",
                    "DialogWidth": "720"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                },
                "/General": {
                    "arrangement": "1",
                    "showToolbox": "false",
                    "toolTips": "true",
                    "url": "activities:/current/"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Blur": "true",
                    "Color": "255,255,255",
                    "FillMode": "2",
                    "Image": "file:///home/eduardo/Imágenes/wallpapers/shin-chan-wallpapers-widwp1837243-3.jpg"
                },
                "/Wallpaper/org.kde.video/General": {
                    "Folder": "file:///home/eduardo/Vídeos/video wallpapers/",
                    "Muted": "true",
                    "Video": "file:///home/eduardo/Vídeos/video wallpapers/Canción de Shin chan el secreto esta en la salsa nueva.mp4"
                }
            },
            "wallpaperPlugin": "org.kde.video"
        }
    ],
    "panels": [
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
